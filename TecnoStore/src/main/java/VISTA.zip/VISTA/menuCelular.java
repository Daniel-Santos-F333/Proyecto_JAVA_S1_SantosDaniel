package VISTA;

import CONTROLADOR.GestionarCelularImpl;
import MODELO.Celular;
import MODELO.CategoriaGama;
import java.util.Scanner;

public class menuCelular {
    GestionarCelularImpl gc = new GestionarCelularImpl();

    public void menu() {
        Scanner sc = new Scanner(System.in);
        int op;
        do {
            System.out.println("""
                               ******************************
                                     GESTIÓN DE CELULARES
                               1.   Registrar
                               2.   Listar Inventario
                               3.   Reporte Stock Bajo (<5)
                               4.   Regresar
                               """);
            op = sc.nextInt();
            switch (op) {
                case 1 -> registrar();
                case 2 -> listar();
                case 3 -> stockBajo();
            }
        } while (op != 4);
    }

    private void registrar() {
        Scanner sc = new Scanner(System.in);
        Celular c = new Celular();
        
        System.out.println("Ingrese Marca ID (1:Samsung, 2:Apple):");
        c.setMarca(sc.nextLine());
        
        System.out.println("Ingrese Modelo:");
        c.setModelo(sc.nextLine());
        
        System.out.println("Ingrese Precio:");
        c.setPrecio(sc.nextDouble());
        
        System.out.println("Ingrese Stock:");
        c.setStock(sc.nextInt());
        sc.nextLine(); // Limpiar buffer
        
        System.out.println("Ingrese Sistema Operativo:");
        c.setSistemaOperativo(sc.nextLine());
        
        System.out.println("Ingrese Gama (ALTA, MEDIA, BAJA):");
        c.setGama(CategoriaGama.valueOf(sc.nextLine().toUpperCase()));
        
        gc.registrar(c);
        System.out.println("¡REGISTRO EXITOSO EN TECNOSTORE!");
    }

    private void listar() {
        System.out.println("\n======= INVENTARIO TOTAL =======");
        gc.listar().forEach(System.out::println); 
    }

    private void stockBajo() {
        System.out.println("\n======= ALERTAS DE REPOSICIÓN =======");
        gc.stockBajo().forEach(System.out::println);
    }
}