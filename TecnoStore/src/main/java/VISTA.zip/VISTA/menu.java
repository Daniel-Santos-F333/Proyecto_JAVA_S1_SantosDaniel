package VISTA;

import java.util.Scanner;

public class menu {
    public void Menu_Principal() {
        Scanner sc = new Scanner(System.in);
        int op;
        do {
            System.out.println("""
                           ******************************
                           1.   Gestionar Celulares
                           2.   Gestionar Clientes
                           3.   Salir
                           """);
            op = sc.nextInt();
            switch (op) {
                case 1 -> {
                    menuCelular mc = new menuCelular();
                    mc.menu();
                }
                case 2 -> System.out.println("Módulo en desarrollo...");
                case 3 -> System.out.println("¡Gracias por usar TecnoStore!");
            }
        } while (op != 3);
    }
}